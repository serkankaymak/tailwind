// pages/index.tsx
import React from "react";
import { AppBar, Box, CssBaseline, Drawer, Toolbar, Typography, Button, Container, BottomNavigation, BottomNavigationAction, Card, CardHeader } from "@mui/material";
import { CardGiftcard, Home, Info, Settings } from "@mui/icons-material";
import styles from "./styles/page.module.css";
import { CardContent, } from '@mui/material';


const drawerWidth = 240;

export default function HomePage() {
  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />

      {/* Top Navigation */}
      <AppBar position="fixed" sx={{ zIndex: 1201 }}>
        <Toolbar style={{ display: "flex", justifyContent: "space-between", paddingInline: 50 }}>
          <Typography variant="h6" noWrap component="div">
            My Application
          </Typography>
          <Button color="inherit">Login</Button>
        </Toolbar>
      </AppBar>

      {/* Sidebar */}
      <Drawer
        variant="permanent"
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          [`& .MuiDrawer-paper`]: { width: drawerWidth, boxSizing: "border-box" },
        }}
      >
        <Toolbar />
        <Box sx={{ overflow: "auto", display: "flex", flexDirection: "column", alignItems: "center", backgroundColor: "red", height: "100vh" }}>
          <Button>Home</Button>
          <Button>About</Button>
          <Button>Settings</Button>
        </Box>
      </Drawer>

      {/* Main Content Area */}
      <Box component="main" sx={{ flexGrow: 1, p: 3, ml: `${drawerWidth}px` }}>

        <Toolbar />
        <Container maxWidth="lg" className={styles.content} style={{ padding: 50, overlay: "inherit" }}>
          <Typography variant="h4" gutterBottom>
            Main Content
          </Typography>
          <Typography variant="body1">
            This is the central content area. Add your main components here.
          </Typography>
          <Card
          >
            <CardHeader> heeader</CardHeader>
            <CardContent>CardContent</CardContent>
            <CardGiftcard></CardGiftcard>
          </Card>


        </Container>
      </Box>

      {/* Footer */}
      <BottomNavigation sx={{ width: "100%", position: "fixed", bottom: 0, backgroundColor: "wheat", zIndex: 9999 }}>
        <BottomNavigationAction label="Home" icon={<Home />} />
        <BottomNavigationAction label="About" icon={<Info />} />
        <BottomNavigationAction label="Settings" icon={<Settings />} />
      </BottomNavigation>
    </Box>
  );
}
