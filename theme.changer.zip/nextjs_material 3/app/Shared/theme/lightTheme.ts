import { createTheme } from '@mui/material/styles';
import { light } from '@mui/material/styles/createPalette';

const lightTheme = createTheme({


    palette: {
        ...light, // Material UI'nin hazır light temasını kullanıyoruz // mode:'light' ile aynı
        primary: {
            main: '#ff5252', // Özel bir ana renk belirtiyoruz
        },
        secondary: {
            main: '#ff4081', // Özel bir ikincil renk belirtiyoruz
        },
    },

});

export default lightTheme;
