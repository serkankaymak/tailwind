import { Theme, ThemeProvider } from '@emotion/react';
import { createTheme, PaletteOptions, Shadows } from '@mui/material/styles';
import { ZIndexOptions } from '@mui/material/styles/zIndex';

const customTheme = createTheme({
    palette: {
        mode: 'light',
        primary: {
            main: '#ff5252',
        },
        secondary: {
            main: '#ff4081',
        },
        background: {
            default: '#f7f7f7', // Arka plan rengi
            paper: '#ffffff',   // Kart, dialog gibi elemanların arka planı
        },
    },
    shadows: Array(25).fill('none') as any, // Tüm gölgeleri kapatmak için "none" değerini kullanıyoruz
});



export default customTheme;
