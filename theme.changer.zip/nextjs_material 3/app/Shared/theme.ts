// src/theme.ts
'use client';
import { createTheme } from '@mui/material/styles';

const theme = createTheme({
    cssVariables: true, // Enable CSS theme variables at the top level
    typography: {
        fontFamily: 'var(--font-roboto)', // Set fontFamily under typography
    },
    // Add other theme customizations here if needed
});

export default theme;


