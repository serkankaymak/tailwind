// components/ThemeProviderClient.tsx
"use client";

import { useState, useMemo, ReactNode } from 'react';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import Button from '@mui/material/Button';
import darkTheme from './theme/darkTheme';
import customTheme from './theme/customTheme';
import lightTheme from './theme/lightTheme';


type ThemeType = 'light' | 'dark' | 'custom';

interface ThemeProviderClientProps {
    children: ReactNode;
}

const ThemeProviderClient = ({ children }: ThemeProviderClientProps) => {
    const [themeType, setThemeType] = useState<ThemeType>('light');

    const theme = useMemo(() => {
        switch (themeType) {
            case 'dark':
                return darkTheme;
            case 'custom':
                return customTheme;
            default:
                return lightTheme;
        }
    }, [themeType]);

    const handleThemeChange = () => {
        setThemeType((prev) =>
            prev === 'light' ? 'dark' : prev === 'dark' ? 'custom' : 'light'
        );
    };

    return (
        <div style={{ backgroundColor: 'yellowgreen', position: "fixed", top: 100, left: 250, width: '100%', height: '100%' }} >
            <ThemeProvider theme={theme}>
                <CssBaseline />
                <div>
                    <Button onClick={handleThemeChange} variant="contained" style={{ margin: 16 }}>
                        {`Switch to ${themeType === 'light' ? 'Dark' : themeType === 'dark' ? 'Custom' : 'Light'} Theme`}
                    </Button>
                    {children}
                </div>

            </ThemeProvider>
        </div>

    );
};

export default ThemeProviderClient;
